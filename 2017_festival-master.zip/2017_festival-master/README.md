# 2017_목포대학교_대동제

<p align="center">
  <img src="README/yolo.JPG" width="600"/>
</p>

-----
> * Lineup 정보
> * 부스정보
> * 주점투표
> * 주점정보, 위치정보
> * [YOLOLION](http://www.yololion.net)
------
> ## 종합결과
> * ![IMG](README/google_report2.JPG)

> ## 9월 25일
> * ![IMG](README/google_report_09_25.JPG)

> ## 9월 26일
> * ![IMG](README/google_report_09_26.JPG)

> ## 9월 27일
> * ![IMG](README/google_report_09_27.JPG)

> ## 9월 28일
> * ![IMG](README/google_report_09_28.JPG)

> ## 9월 29일
> * ![IMG](README/google_report_09_29.JPG)

